# Pod Korunami – statický web

Obsah:
- index.html (hlavní stránka)
- gallery.html (fotogalerie)
- assets/css/style.css
- assets/js/script.js
- assets/img/ (optimalizované fotky)
- CNAME (doména)

Publikace:
1. Nahrajte do repozitáře podkorunami-ai.github.io.
2. Aktivujte GitHub Pages (Settings → Pages).
3. DNS na Active24: A záznamy pro apex, CNAME pro www.
